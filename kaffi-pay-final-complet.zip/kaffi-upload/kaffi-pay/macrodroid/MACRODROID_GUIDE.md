# KAFFI PAY — Guide MacroDroid
# 2 Macros : Waafi kaffi + Webhook

## ══════════════════════════════════════════
## MACRO 1 : "Waafi kaffi"
## Notification Waafi → Firebase Backend
## ══════════════════════════════════════════

### TRIGGER
- Type : Notification reçue
- App  : WAAFI

### ACTIONS

#### Action 1 : Requête HTTP (POST)
- URL : https://europe-west1-kaffi-pay.cloudfunctions.net/api/waafiWebhook
- Méthode : POST
- Headers :
    Content-Type: application/json
    x-webhook-secret: kaffi-webhook-2026-mZ3
- Body :
{
  "notificationText": "[notification_text]",
  "notificationTitle": "[notification_title]",
  "app": "Waafi",
  "receivedAt": "[time_stamp_iso]",
  "device": "MacroDroid"
}

#### Action 2 : Vibration (Rapide)
- Déjà configuré ✅

---

## ══════════════════════════════════════════
## MACRO 2 : "Webhook"
## Firebase → MacroDroid → MobCash
## ══════════════════════════════════════════

### TRIGGER
- Type : Hook Web
- Nom  : recharge_automatique
- URL  : https://trigger.macrodroid.com/f3af9af3-7f05-401d-ade2-df70f6880dcb/recharge_automatique

### ACTIONS
#### Action 1 : Lancer MobCash
- Déjà configuré ✅

#### Action 2 : Vibration (Rapide)
- Déjà configuré ✅

---

## ══════════════════════════════════════════
## FLUX COMPLET AUTOMATIQUE
## ══════════════════════════════════════════

1. Client envoie paiement Waafi → ton numéro 77043065
2. Notification Waafi reçue sur ton téléphone
3. MacroDroid "Waafi kaffi" se déclenche
4. HTTP POST → Firebase avec le texte de la notification
5. Firebase lit le Transfer-ID et le montant via Gemini AI
6. Firebase trouve l'ordre correspondant dans Firestore
7. Firebase met le statut → "Argent Reçu"
8. Firebase appelle le webhook MacroDroid :
   https://trigger.macrodroid.com/f3af9af3-7f05-401d-ade2-df70f6880dcb/recharge_automatique
9. MacroDroid "Webhook" se déclenche → lance MobCash
10. MobCash crédite le compte 1xBet automatiquement

---

## ══════════════════════════════════════════
## VÉRIFICATION
## ══════════════════════════════════════════

Test manuel Firebase → MacroDroid :
Ouvre Chrome et colle cette URL :
https://trigger.macrodroid.com/f3af9af3-7f05-401d-ade2-df70f6880dcb/recharge_automatique

Si MobCash se lance → Webhook OK ✅

Test manuel Waafi kaffi :
Envoie-toi un virement Waafi test de 50 DJF
→ Vérifie dans Firebase Console → Firestore → orders
→ Un ordre doit passer en "Argent Reçu"

