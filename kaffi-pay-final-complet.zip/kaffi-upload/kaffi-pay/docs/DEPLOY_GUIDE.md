# KAFFI PAY — Guide Déploiement Complet
## Du zéro au production en 6 étapes

---

## ÉTAPE 1 — Prérequis

```bash
# Installer Node.js 18+
node --version   # doit afficher v18.x ou +

# Installer Firebase CLI
npm install -g firebase-tools

# Installer les dépendances des functions
cd functions
npm install
cd ..
```

---

## ÉTAPE 2 — Configuration Firebase

### 2.1 Connexion Firebase
```bash
firebase login
firebase use kaffi-pay
```

### 2.2 Variables d'environnement (Firebase Functions)
```bash
# Définir chaque variable :
firebase functions:secrets:set GEMINI_API_KEY
# → entrer votre clé Gemini quand demandé

firebase functions:secrets:set JWT_SECRET
# → entrer un secret aléatoire (minimum 32 chars)

firebase functions:secrets:set ADMIN_PASS
# → entrer votre mot de passe admin

firebase functions:secrets:set WEBHOOK_SECRET
# → entrer votre secret webhook MacroDroid
```

### 2.3 Ajouter les secrets dans index.js
Dans `functions/index.js`, ajouter :
```javascript
const { defineSecret } = require("firebase-functions/params");
const GEMINI_API_KEY  = defineSecret("GEMINI_API_KEY");
const JWT_SECRET      = defineSecret("JWT_SECRET");
const WEBHOOK_SECRET  = defineSecret("WEBHOOK_SECRET");
```

---

## ÉTAPE 3 — Obtenir la clé Gemini AI

1. Aller sur https://aistudio.google.com/app/apikey
2. Cliquer "Create API Key"
3. Sélectionner projet "kaffi-pay"
4. Copier la clé
5. Définir : `firebase functions:secrets:set GEMINI_API_KEY`

---

## ÉTAPE 4 — Déploiement

### 4.1 Déployer Firestore rules + indexes
```bash
firebase deploy --only firestore
```

### 4.2 Déployer les Cloud Functions
```bash
firebase deploy --only functions
```

### 4.3 Récupérer l'URL des functions
```bash
firebase functions:list
# Copier l'URL : https://europe-west1-kaffi-pay.cloudfunctions.net/api
```

---

## ÉTAPE 5 — Configurer MacroDroid

1. Installer MacroDroid sur le téléphone admin
2. Aller dans : Menu → Macros → Add Macro
3. Suivre le guide : `macrodroid/MACRODROID_GUIDE.md`
4. Remplacer `backend_url` par votre URL Firebase Functions
5. Tester avec le bouton "Run" dans MacroDroid

---

## ÉTAPE 6 — Deployer le Frontend sur Netlify

### 6.1 Depuis le dashboard Netlify
- New Site → Import from Git → sélectionner repo
- Build command : (vide — fichier HTML statique)
- Publish directory : `frontend`

### 6.2 Variables d'environnement Netlify
Dans Site Settings → Environment Variables :

| Clé                         | Valeur                                              |
|-----------------------------|-----------------------------------------------------|
| VITE_FIREBASE_API_KEY       | AIzaSyCILUjQPp_wO-IJrp6WwckMRDN5ISbcexU           |
| VITE_FIREBASE_PROJECT_ID    | kaffi-pay                                           |
| VITE_FUNCTIONS_URL          | https://europe-west1-kaffi-pay.cloudfunctions.net/api |

### 6.3 Domaine autorisé Firebase
Firebase Console → Authentication → Settings → Authorized domains
→ Ajouter : `ffipay.netlify.app`

---

## TESTS API

### Test health check
```bash
curl https://europe-west1-kaffi-pay.cloudfunctions.net/api/health
```

### Test createOrder
```bash
curl -X POST https://europe-west1-kaffi-pay.cloudfunctions.net/api/createOrder \
  -H "Content-Type: application/json" \
  -d '{
    "type": "Dépôt",
    "montant": 1500,
    "userId1xBet": "4245454828",
    "waafitranfertID": "2131212121",
    "numeroPayment": "77043152"
  }'
```

### Test waafiWebhook (simuler MacroDroid)
```bash
curl -X POST https://europe-west1-kaffi-pay.cloudfunctions.net/api/waafiWebhook \
  -H "Content-Type: application/json" \
  -H "x-webhook-secret: kaffi-webhook-secret" \
  -d '{
    "notificationText": "WAAFI -> Transfer-Id: 2131212121, You have Received DJF 1,580 from Client(77043152), Your Balance is: DJF 5,000.00.",
    "app": "Waafi",
    "receivedAt": "2026-05-29T00:22:58Z"
  }'
```

### Test admin login
```bash
curl -X POST https://europe-west1-kaffi-pay.cloudfunctions.net/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "VotreMotDePasse"}'
```

---

## WORKFLOW COMPLET (résumé)

```
Client → Soumet dépôt sur ffipay.netlify.app
       → Frontend envoie à Firebase Firestore (collection orders)
       → Ordre créé avec status "En attente"

Client → Effectue virement Waafi

Waafi → Envoie notification Android

MacroDroid → Détecte notification Waafi
           → HTTP POST → Firebase Function /waafiWebhook
           → Gemini AI analyse le texte brut
           → Match avec ordre en attente
           → Update Firestore status → "Argent Reçu"

Admin → Voit ordre mis à jour en temps réel (Firestore listener)
      → Confirme manuellement → status "Confirmé"
      → Client voit la mise à jour en temps réel sur son écran suivi
```

---

## LOGS ET MONITORING

```bash
# Logs en temps réel
firebase functions:log --only api

# Logs des dernières 24h
firebase functions:log --only api --limit 100
```

---

## STRUCTURE FINALE DU PROJET

```
kaffi-pay/
├── frontend/
│   └── index.html              ← Votre SPA existante
├── functions/
│   ├── index.js                ← Entry point Express
│   ├── shared.js               ← Firebase + Gemini init
│   ├── package.json
│   ├── routes/
│   │   ├── createOrder.js      ← Création ordres
│   │   ├── waafiWebhook.js     ← Réception notifications Waafi + IA
│   │   ├── verifyPayment.js    ← Validation manuelle admin
│   │   ├── updateOrderStatus.js← Mise à jour statuts
│   │   ├── detectFraud.js      ← Analyse fraude Gemini
│   │   └── adminAuth.js        ← Login admin JWT
│   └── middleware/
│       └── auth.js             ← Middleware auth JWT
├── firestore/
│   ├── firestore.rules         ← Règles sécurité
│   └── firestore.indexes.json  ← Index Firestore
├── macrodroid/
│   └── MACRODROID_GUIDE.md     ← Config MacroDroid complète
├── firebase.json               ← Config Firebase
└── .env.example                ← Template variables
```
