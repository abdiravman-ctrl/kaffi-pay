/**
 * KAFFI PAY — Firebase Cloud Functions
 * Backend complet : ordres, webhook Waafi, validation IA, admin
 * Node.js 18 + Express.js
 */

const { onRequest } = require("firebase-functions/v2/https");
const { setGlobalOptions } = require("firebase-functions/v2");
const { defineSecret } = require("firebase-functions/params");
const express = require("express");
const cors = require("cors");

// ── Secrets Firebase ──
const GEMINI_API_KEY  = defineSecret("GEMINI_API_KEY");
const JWT_SECRET      = defineSecret("JWT_SECRET");
const WEBHOOK_SECRET  = defineSecret("WEBHOOK_SECRET");
const ADMIN_PASS      = defineSecret("ADMIN_PASS");

// ── Global options ──
setGlobalOptions({ region: "europe-west1", maxInstances: 10 });

// ── Express app ──
const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: "10mb" }));

// ── Routes ──
const createOrder    = require("./routes/createOrder");
const waafiWebhook   = require("./routes/waafiWebhook");
const verifyPayment  = require("./routes/verifyPayment");
const updateStatus   = require("./routes/updateOrderStatus");
const detectFraud    = require("./routes/detectFraud");
const adminAuth      = require("./routes/adminAuth");

app.use("/createOrder",       createOrder);
app.use("/waafiWebhook",      waafiWebhook);
app.use("/verifyPayment",     verifyPayment);
app.use("/updateOrderStatus", updateStatus);
app.use("/detectFraud",       detectFraud);
app.use("/admin",             adminAuth);

// ── Health check ──
app.get("/health", (req, res) => {
  res.json({ status: "ok", service: "Kaffi Pay Backend", ts: new Date().toISOString() });
});

// ── 404 handler ──
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// ── Error handler ──
app.use((err, req, res, next) => {
  console.error("💥 Unhandled error:", err);
  res.status(500).json({ error: "Internal server error", message: err.message });
});

// ── Export avec secrets déclarés ──
exports.api = onRequest(
  {
    timeoutSeconds: 60,
    secrets: [GEMINI_API_KEY, JWT_SECRET, WEBHOOK_SECRET, ADMIN_PASS],
  },
  app
);
