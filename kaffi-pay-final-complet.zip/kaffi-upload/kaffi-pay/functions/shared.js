/**
 * KAFFI PAY — Shared Firebase & Gemini initialisation
 * Importé par toutes les routes
 */

const admin = require("firebase-admin");
const { GoogleGenerativeAI } = require("@google/generative-ai");

// ── Firebase Admin (singleton) ──
if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

// ── Gemini AI (lazy init pour lire le secret au runtime) ──
let _geminiModel = null;
function getGeminiModel() {
  if (!_geminiModel) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) throw new Error("GEMINI_API_KEY secret non défini");
    const genAI = new GoogleGenerativeAI(key);
    _geminiModel = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  }
  return _geminiModel;
}

// ── Collections Firestore ──
const COLLECTIONS = {
  ORDERS:        "orders",
  NOTIFICATIONS: "waafi_notifications",
  FRAUD_LOGS:    "fraud_logs",
  ADMIN_LOGS:    "admin_logs",
};

// ── Statuts commande ──
const STATUS = {
  PENDING:    "En attente",
  RECEIVED:   "Argent Reçu",
  CONFIRMED:  "Confirmé",
  REJECTED:   "Rejeté",
  CORRECTION: "Correction",
};

module.exports = { admin, db, getGeminiModel, COLLECTIONS, STATUS };
