/**
 * KAFFI PAY — Route : adminAuth
 * POST /api/admin/login
 * GET  /api/admin/verify
 * Authentification admin avec JWT simple
 */

const router = require("express").Router();
const { db, COLLECTIONS } = require("../shared");
const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS;

// POST /admin/login
router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ success: false, error: "username et password requis" });
    }

    // Vérification credentials
    if (username !== ADMIN_USER || password !== ADMIN_PASS) {
      // Log tentative échouée
      await db.collection(COLLECTIONS.ADMIN_LOGS).add({
        event: "login_failed",
        username,
        ip: req.ip,
        createdAt: new Date(),
      });
      return res.status(401).json({ success: false, error: "Identifiants incorrects" });
    }

    // Générer JWT (expire 8h)
    const token = jwt.sign(
      { username, role: "admin" },
      JWT_SECRET,
      { expiresIn: "8h" }
    );

    await db.collection(COLLECTIONS.ADMIN_LOGS).add({
      event: "login_success",
      username,
      ip: req.ip,
      createdAt: new Date(),
    });

    console.log(`✅ Admin login: ${username}`);

    return res.status(200).json({
      success: true,
      token,
      expiresIn: "8h",
      role: "admin",
    });

  } catch (err) {
    console.error("❌ adminAuth login error:", err);
    return res.status(500).json({ success: false, error: "Erreur serveur" });
  }
});

// GET /admin/verify
router.get("/verify", (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ valid: false, error: "Token manquant" });
    }
    const token = authHeader.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    return res.status(200).json({ valid: true, user: decoded });
  } catch (err) {
    return res.status(401).json({ valid: false, error: "Token invalide ou expiré" });
  }
});

module.exports = router;
