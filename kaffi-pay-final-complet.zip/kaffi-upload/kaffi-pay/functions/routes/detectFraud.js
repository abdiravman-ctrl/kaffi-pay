/**
 * KAFFI PAY — Route : detectFraud
 * POST /api/detectFraud
 * Analyse de fraude IA via Gemini sur un ordre suspect
 */

const router = require("express").Router();
const { db, getGeminiModel, COLLECTIONS } = require("../shared");

async function analyzeWithGemini(order, notificationText) {
  const prompt = `
Tu es un expert en détection de fraude pour une plateforme de paiement mobile à Djibouti.

Analyse cet ordre de paiement et détermine s'il est frauduleux.

ORDRE :
${JSON.stringify(order, null, 2)}

NOTIFICATION WAAFI REÇUE :
"${notificationText}"

CRITÈRES DE FRAUDE :
1. Le montant reçu correspond-il exactement au montant de l'ordre ? (tolérance 0 DJF)
2. Le Transfer-Id de l'ordre correspond-il à celui de la notification ?
3. Le numéro Waafi expéditeur est-il valide (format 77XXXXXX) ?
4. La notification semble-t-elle authentique (format Waafi standard) ?
5. Y a-t-il des incohérences entre les données de l'ordre et la notification ?

RÉPONDS UNIQUEMENT EN JSON VALIDE :
{
  "isFraud": false,
  "fraudScore": 0.05,
  "confidence": 0.95,
  "reasons": [],
  "recommendation": "approve",
  "details": {
    "amountMatch": true,
    "transferIdMatch": true,
    "numberValid": true,
    "notificationAuthentic": true,
    "inconsistencies": []
  }
}

recommendation doit être : "approve" | "reject" | "manual_review"
`;

  try {
    const result = await getGeminiModel().generateContent(prompt);
    const text = result.response.text().trim().replace(/```json|```/g, "").trim();
    return { success: true, analysis: JSON.parse(text) };
  } catch (err) {
    console.error("⚠️ Gemini fraud analysis failed:", err.message);
    return {
      success: false,
      analysis: {
        isFraud: false,
        fraudScore: 0.5,
        confidence: 0.3,
        reasons: ["ai_analysis_failed"],
        recommendation: "manual_review",
      },
    };
  }
}

router.post("/", async (req, res) => {
  try {
    const { orderId, notificationText } = req.body;

    if (!orderId) {
      return res.status(400).json({ success: false, error: "orderId requis" });
    }

    // Récupérer l'ordre
    const snap = await db.collection(COLLECTIONS.ORDERS)
      .where("orderId", "==", String(orderId))
      .limit(1).get();

    if (snap.empty) {
      return res.status(404).json({ success: false, error: "Ordre non trouvé" });
    }

    const order = snap.docs[0].data();
    const { success, analysis } = await analyzeWithGemini(order, notificationText || "");

    // Log fraude si suspectée
    if (analysis.fraudScore > 0.6) {
      await db.collection(COLLECTIONS.FRAUD_LOGS).add({
        orderId,
        order,
        analysis,
        notificationText,
        createdAt: new Date(),
      });
      console.warn(`🚨 Fraude détectée sur ordre ${orderId} - score: ${analysis.fraudScore}`);
    }

    return res.status(200).json({
      success: true,
      orderId,
      aiSuccess: success,
      analysis,
    });

  } catch (err) {
    console.error("❌ detectFraud error:", err);
    return res.status(500).json({ success: false, error: "Erreur serveur" });
  }
});

module.exports = router;
