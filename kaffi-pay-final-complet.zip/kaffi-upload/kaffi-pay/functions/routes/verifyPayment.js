/**
 * KAFFI PAY — Route : verifyPayment
 * POST /api/verifyPayment
 * Vérifie manuellement un paiement (utilisé par l'admin)
 */

const router = require("express").Router();
const { db, COLLECTIONS, STATUS } = require("../shared");
const { verifyAdminToken } = require("../middleware/auth");

// POST /verifyPayment
router.post("/", verifyAdminToken, async (req, res) => {
  try {
    const { orderId, action } = req.body;
    // action: "confirm" | "reject" | "correction"
    if (!orderId || !action) {
      return res.status(400).json({ success: false, error: "orderId et action requis" });
    }

    // Trouver l'ordre
    const snap = await db.collection(COLLECTIONS.ORDERS)
      .where("orderId", "==", orderId)
      .limit(1).get();

    if (snap.empty) {
      return res.status(404).json({ success: false, error: "Ordre introuvable" });
    }

    const doc = snap.docs[0];
    const statusMap = {
      confirm:    STATUS.CONFIRMED,
      reject:     STATUS.REJECTED,
      correction: STATUS.CORRECTION,
    };

    const newStatus = statusMap[action];
    if (!newStatus) {
      return res.status(400).json({ success: false, error: "Action invalide" });
    }

    await doc.ref.update({
      status: newStatus,
      updatedAt: new Date(),
      updatedBy: req.adminUser || "admin",
      correctionMsg: req.body.correctionMsg || null,
    });

    console.log(`✅ Ordre ${orderId} → ${newStatus}`);

    return res.status(200).json({ success: true, orderId, newStatus });

  } catch (err) {
    console.error("❌ verifyPayment error:", err);
    return res.status(500).json({ success: false, error: "Erreur serveur" });
  }
});

module.exports = router;
