/**
 * KAFFI PAY — Route : createOrder
 * POST /api/createOrder
 * Crée un nouvel ordre dépôt ou retrait dans Firestore
 */

const router = require("express").Router();
const { db, COLLECTIONS, STATUS } = require("../shared");

// ── Validation dépôt ──
function validateDepot(body) {
  const errors = [];
  if (!body.montant || Number(body.montant) < 50)
    errors.push("Montant minimum 50 DJF");
  if (!body.userId1xBet || body.userId1xBet.trim().length < 3)
    errors.push("ID 1xBet requis");
  if (!body.waafitranfertID || !/^\d{8,12}$/.test(body.waafitranfertID))
    errors.push("Waafi Transfer ID invalide (8-12 chiffres)");
  return errors;
}

// ── Validation retrait ──
function validateRetrait(body) {
  const errors = [];
  if (!body.montant || Number(body.montant) < 250)
    errors.push("Montant minimum 250 DJF");
  if (!body.withdrawalCode || body.withdrawalCode.trim().length !== 4)
    errors.push("Code retrait 4 caractères requis");
  if (!body.waafiNumber || !/^77\d{6}$/.test(body.waafiNumber))
    errors.push("Numéro Waafi invalide (8 chiffres, commence par 77)");
  return errors;
}

// ── Anti-spam : 1 ordre par numéro toutes les 2 minutes ──
async function checkSpam(identifier) {
  const twoMinAgo = new Date(Date.now() - 2 * 60 * 1000);
  const snap = await db.collection(COLLECTIONS.ORDERS)
    .where("spamKey", "==", identifier)
    .where("createdAt", ">=", twoMinAgo)
    .limit(1)
    .get();
  return !snap.empty;
}

// ── POST /createOrder ──
router.post("/", async (req, res) => {
  try {
    const body = req.body;
    const type = body.type; // "Dépôt" ou "Retrait"

    if (!type || !["Dépôt", "Retrait"].includes(type)) {
      return res.status(400).json({ success: false, error: "Type invalide (Dépôt ou Retrait)" });
    }

    // Validation selon type
    const errors = type === "Dépôt" ? validateDepot(body) : validateRetrait(body);
    if (errors.length > 0) {
      return res.status(400).json({ success: false, errors });
    }

    // Anti-spam
    const spamKey = type === "Dépôt"
      ? `depot_${body.userId1xBet}`
      : `retrait_${body.waafiNumber}`;

    const isSpam = await checkSpam(spamKey);
    if (isSpam) {
      return res.status(429).json({
        success: false,
        error: "Trop de demandes. Attendez 2 minutes avant de réessayer.",
      });
    }

    // Génération orderId
    const orderId = String(Math.floor(100000 + Math.random() * 900000));
    const now = new Date();
    const dateStr = now.toISOString().replace("T", " ").substring(0, 19);

    // Construction document Firestore
    const orderDoc = {
      orderId,
      ref: orderId,
      type,
      montant: Number(body.montant),
      amount: Number(body.montant).toLocaleString("fr-FR") + " DJF",
      status: STATUS.PENDING,
      createdAt: admin_ts(),
      date: dateStr,
      spamKey,
      ip: req.ip || "unknown",
      // Dépôt
      ...(type === "Dépôt" && {
        userId1xBet: body.userId1xBet.trim(),
        waafitranfertID: body.waafitranfertID.trim(),
        methodePayment: "Waafi",
        numeroPayment: body.numeroPayment || "—",
      }),
      // Retrait
      ...(type === "Retrait" && {
        withdrawalCode: body.withdrawalCode.trim(),
        waafiNumber: body.waafiNumber.trim(),
        methodeRecepteur: "Waafi",
      }),
    };

    // Sauvegarde Firestore
    const docRef = await db.collection(COLLECTIONS.ORDERS).add(orderDoc);

    console.log(`✅ Ordre créé : ${orderId} | Type: ${type} | Montant: ${body.montant} DJF`);

    return res.status(201).json({
      success: true,
      orderId,
      firestoreId: docRef.id,
      message: "Ordre créé avec succès",
    });

  } catch (err) {
    console.error("❌ createOrder error:", err);
    return res.status(500).json({ success: false, error: "Erreur serveur" });
  }
});

// Helper Firestore timestamp
function admin_ts() {
  const { admin } = require("../shared");
  return admin.firestore.FieldValue.serverTimestamp();
}

module.exports = router;
