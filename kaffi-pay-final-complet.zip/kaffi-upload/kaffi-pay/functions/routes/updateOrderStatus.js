/**
 * KAFFI PAY — Route : updateOrderStatus
 * POST /api/updateOrderStatus
 * Met à jour le statut d'un ordre (appelé par frontend admin)
 */

const router = require("express").Router();
const { db, COLLECTIONS, STATUS } = require("../shared");

const VALID_STATUSES = Object.values(STATUS);

router.post("/", async (req, res) => {
  try {
    const { orderId, newStatus, correctionMsg } = req.body;

    if (!orderId) {
      return res.status(400).json({ success: false, error: "orderId requis" });
    }
    if (!newStatus || !VALID_STATUSES.includes(newStatus)) {
      return res.status(400).json({
        success: false,
        error: `Statut invalide. Valeurs acceptées : ${VALID_STATUSES.join(", ")}`,
      });
    }

    // Trouver par orderId
    const snap = await db.collection(COLLECTIONS.ORDERS)
      .where("orderId", "==", String(orderId))
      .limit(1).get();

    if (snap.empty) {
      return res.status(404).json({ success: false, error: "Ordre non trouvé" });
    }

    const updateData = {
      status: newStatus,
      updatedAt: new Date(),
    };
    if (correctionMsg) updateData.correctionMsg = correctionMsg;

    await snap.docs[0].ref.update(updateData);

    console.log(`📝 Ordre ${orderId} : ${snap.docs[0].data().status} → ${newStatus}`);

    return res.status(200).json({ success: true, orderId, newStatus });

  } catch (err) {
    console.error("❌ updateOrderStatus error:", err);
    return res.status(500).json({ success: false, error: "Erreur serveur" });
  }
});

module.exports = router;
