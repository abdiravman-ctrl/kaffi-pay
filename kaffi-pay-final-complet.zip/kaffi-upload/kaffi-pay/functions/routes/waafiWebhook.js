/**
 * KAFFI PAY — Route : waafiWebhook
 * POST /api/waafiWebhook
 * Reçoit la notification Waafi brute depuis MacroDroid
 * → Gemini AI parse → match ordre → update Firestore
 */

const router = require("express").Router();
const { db, getGeminiModel, COLLECTIONS, STATUS } = require("../shared");

// ── Prompt Gemini complet ──
function buildGeminiPrompt(notificationText) {
  return `
Tu es un agent de validation de paiement pour Kaffi Pay, une plateforme d'échange 1xBet ↔ Waafi à Djibouti.

Analyse cette notification Waafi brute et extrais les informations structurées.

NOTIFICATION BRUTE :
"${notificationText}"

INSTRUCTIONS :
1. Extrais EXACTEMENT les données présentes dans le texte
2. Ne devine pas — si une donnée est absente, mets null
3. Le montant est toujours en DJF (Francs Djiboutiens)
4. Le Transfer-Id est un identifiant numérique unique
5. Le numéro expéditeur est au format 77XXXXXX (8 chiffres)
6. Calcule un score de confiance entre 0.0 et 1.0
7. Détecte les signaux de fraude potentielle

SIGNAUX DE FRAUDE À DÉTECTER :
- Montant anormalement élevé (> 500,000 DJF)
- Numéro expéditeur inconnu ou format invalide
- Texte de notification modifié ou incohérent
- Tentative de double paiement (même Transfer-Id)
- Texte tronqué ou incomplet

RÉPONDS UNIQUEMENT EN JSON VALIDE, sans markdown, sans backticks :
{
  "isValid": true,
  "transactionType": "received",
  "amount": 4400,
  "currency": "DJF",
  "transferId": "75757946",
  "senderNumber": "77211855",
  "senderName": "Fouad Osman Doubad",
  "balanceAfter": 4403.06,
  "rawText": "${notificationText.replace(/"/g, '\\"')}",
  "confidence": 0.97,
  "fraudSignals": [],
  "fraudScore": 0.02,
  "parseNotes": "Notification valide, tous les champs extraits"
}
`;
}

// ── Appel Gemini avec fallback regex ──
async function parseWithGemini(notificationText) {
  try {
    const prompt = buildGeminiPrompt(notificationText);
    const result = await getGeminiModel().generateContent(prompt);
    const text = result.response.text().trim();

    // Nettoyage réponse (enlever backticks si présents)
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    console.log("🤖 Gemini parse OK:", JSON.stringify(parsed));
    return { success: true, data: parsed };

  } catch (err) {
    console.error("⚠️ Gemini parse failed, using regex fallback:", err.message);
    return { success: false, data: regexFallback(notificationText) };
  }
}

// ── Fallback regex si Gemini échoue ──
function regexFallback(text) {
  const transferMatch = text.match(/Transfer-Id[:\s]+(\d+)/i);
  const amountMatch   = text.match(/(?:Received|heshay)\s+DJF\s+([\d,]+)/i);
  const numberMatch   = text.match(/\((\d{8})\)/);
  const amount = amountMatch
    ? parseFloat(amountMatch[1].replace(/,/g, ""))
    : null;

  return {
    isValid: !!(transferMatch || amountMatch),
    transactionType: "received",
    amount,
    currency: "DJF",
    transferId: transferMatch ? transferMatch[1] : null,
    senderNumber: numberMatch ? numberMatch[1] : null,
    senderName: null,
    balanceAfter: null,
    confidence: 0.6,
    fraudSignals: ["parsed_by_fallback"],
    fraudScore: 0.1,
    parseNotes: "Fallback regex (Gemini indisponible)",
  };
}

// ── Match ordre en attente ──
async function findMatchingOrder(parsed) {
  const { transferId, amount, senderNumber } = parsed;
  const orders = await db.collection(COLLECTIONS.ORDERS)
    .where("type", "==", "Dépôt")
    .where("status", "==", STATUS.PENDING)
    .limit(50)
    .get();

  for (const doc of orders.docs) {
    const order = doc.data();
    // Match par Transfer ID (priorité)
    if (transferId && order.waafitranfertID === transferId) {
      return { doc, order, matchType: "transferId" };
    }
    // Match par montant exact
    if (amount && Number(order.montant) === amount) {
      return { doc, order, matchType: "amount" };
    }
    // Match montant + numéro expéditeur
    if (amount && senderNumber &&
        Number(order.montant) === amount &&
        order.numeroPayment === senderNumber) {
      return { doc, order, matchType: "amount+number" };
    }
  }
  return null;
}

// ── POST /waafiWebhook ──
router.post("/", async (req, res) => {
  try {
    const { notificationText, app, receivedAt } = req.body;

    if (!notificationText || notificationText.trim().length < 10) {
      return res.status(400).json({
        success: false,
        error: "notificationText requis et non vide",
      });
    }

    console.log(`📲 Webhook Waafi reçu: "${notificationText.substring(0, 80)}..."`);

    // 1. Parse avec Gemini AI
    const { success: geminiOk, data: parsed } = await parseWithGemini(notificationText);

    // 2. Sauvegarder notification brute dans Firestore
    const notifRef = await db.collection(COLLECTIONS.NOTIFICATIONS).add({
      notificationText,
      app: app || "Waafi",
      receivedAt: receivedAt || new Date().toISOString(),
      parsedData: parsed,
      geminiSuccess: geminiOk,
      status: "received",
      createdAt: new Date(),
    });

    // 3. Vérifier fraude
    if (parsed.fraudScore > 0.7) {
      await notifRef.update({ status: "fraud_suspected" });
      await db.collection(COLLECTIONS.FRAUD_LOGS).add({
        notificationText,
        parsed,
        reason: "fraud_score_high",
        fraudScore: parsed.fraudScore,
        createdAt: new Date(),
      });
      console.warn(`🚨 Fraude suspectée - score: ${parsed.fraudScore}`);
      return res.status(200).json({
        success: false,
        matched: false,
        reason: "fraud_suspected",
        fraudScore: parsed.fraudScore,
      });
    }

    // 4. Si notification invalide ou non-réception
    if (!parsed.isValid || parsed.transactionType !== "received") {
      await notifRef.update({ status: "not_a_payment" });
      return res.status(200).json({
        success: false,
        matched: false,
        reason: "not_a_payment_notification",
      });
    }

    // 5. Trouver ordre matching
    const match = await findMatchingOrder(parsed);

    if (!match) {
      await notifRef.update({ status: "no_order_found" });
      console.warn(`⚠️ Aucun ordre trouvé pour: ${JSON.stringify(parsed)}`);
      return res.status(200).json({
        success: false,
        matched: false,
        reason: "no_matching_order",
        parsed,
      });
    }

    const { doc, order, matchType } = match;

    // 6. Mettre à jour ordre → "Argent Reçu"
    await doc.ref.update({
      status: STATUS.RECEIVED,
      transferIdRecu: parsed.transferId || "",
      montantRecu: parsed.amount,
      expediteurRecu: parsed.senderNumber || "",
      senderName: parsed.senderName || "",
      aiConfidence: parsed.confidence,
      aiFraudScore: parsed.fraudScore,
      matchType,
      matchedAt: new Date(),
      notifId: notifRef.id,
    });

    // 7. Marquer notification comme matchée
    await notifRef.update({
      status: "matched",
      ordreRef: order.orderId,
      matchType,
    });

    console.log(`✅ Match trouvé: Ordre #${order.orderId} | Montant: ${parsed.amount} DJF | Match: ${matchType}`);

    // 8. Déclencher MacroDroid → MobCash automatiquement
    try {
      const https = require('https');
      const macroUrl = 'https://trigger.macrodroid.com/f3af9af3-7f05-401d-ade2-df70f6880dcb/recharge_automatique';
      https.get(macroUrl + '?orderId=' + order.orderId + '&amount=' + parsed.amount, (r) => {
        console.log('🤖 MacroDroid triggered:', r.statusCode);
      }).on('error', (e) => console.warn('MacroDroid trigger failed:', e.message));
    } catch(e) { console.warn('MacroDroid call error:', e.message); }

    return res.status(200).json({
      success: true,
      matched: true,
      orderId: order.orderId,
      matchType,
      amount: parsed.amount,
      confidence: parsed.confidence,
    });

  } catch (err) {
    console.error("❌ waafiWebhook error:", err);
    return res.status(500).json({ success: false, error: "Erreur serveur" });
  }
});

module.exports = router;
