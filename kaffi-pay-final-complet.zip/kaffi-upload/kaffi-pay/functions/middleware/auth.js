/**
 * KAFFI PAY — Middleware : Auth
 * Vérifie le token JWT pour les routes admin protégées
 */

const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET;

function verifyAdminToken(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ success: false, error: "Token d'authentification requis" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.adminUser = decoded.username;
    req.adminRole = decoded.role;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, error: "Token invalide ou expiré" });
  }
}

// Middleware webhook secret (MacroDroid)
function verifyWebhookSecret(req, res, next) {
  const secret = req.headers["x-webhook-secret"] || req.body?.webhookSecret;
  const expected = process.env.WEBHOOK_SECRET;

  if (secret !== expected) {
    console.warn(`⚠️ Webhook secret invalide depuis ${req.ip}`);
    return res.status(403).json({ success: false, error: "Webhook secret invalide" });
  }
  next();
}

module.exports = { verifyAdminToken, verifyWebhookSecret };
